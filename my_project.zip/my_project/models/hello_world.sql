SELECT 1 AS id, 'hello_dbt' AS message
