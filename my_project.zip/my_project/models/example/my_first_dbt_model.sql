{{ config(materialized='view') }}

SELECT 'ok' AS status
