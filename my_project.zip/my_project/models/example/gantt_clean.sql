{{ config(materialized='view') }}

SELECT 
    "Task"       AS task,
    CAST("Start" AS DATE) AS start_date,
    CAST("End"   AS DATE) AS end_date,
    "Owner"      AS owner
FROM project_timeline

