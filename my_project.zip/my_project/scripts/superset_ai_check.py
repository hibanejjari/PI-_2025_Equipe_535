import pandas as pd
from superset_check import validate_superset
from openai import OpenAI

def ai_summary(report_path="superset_vs_reference_report.csv"):
    df = pd.read_csv(report_path)

    mismatches = df[df["status"] == "mismatch"]
    missing_superset = df[df["status"] == "missing_in_superset"]
    missing_ref = df[df["status"] == "missing_in_ref"]

    summary_text = (
        f"Validation Report:\n\n"
        f"- Total rows: {len(df)}\n"
        f"- Matches: {(df['status'] == 'match').sum()}\n"
        f"- Mismatches: {len(mismatches)}\n"
        f"- Missing in Superset: {len(missing_superset)}\n"
        f"- Missing in Reference: {len(missing_ref)}\n"
    )

    print(summary_text)

    # Generate natural language summary
    client = OpenAI()
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a data quality assistant."},
            {"role": "user", "content": f"Here is a validation summary:\n{summary_text}\n\nWrite a short report with insights and possible causes."}
        ]
    )

    ai_report = response.choices[0].message.content
    with open("ai_validation_report.txt", "w") as f:
        f.write(ai_report)

    print("\nAI-generated summary saved to ai_validation_report.txt")


if __name__ == "__main__":
    validate_superset()
    ai_summary()
