import requests
import pandas as pd

BASE = "http://localhost:8088"
USER = "admin"
PWD = "admin"

def fetch_superset_dataset(dataset_id: int, row_limit: int = 1000) -> pd.DataFrame:
    """Fetch dataset from Superset by ID."""
    session = requests.Session()

    # Login
    r = session.post(
        f"{BASE}/api/v1/security/login",
        json={"provider": "db", "username": USER, "password": PWD, "refresh": True},
        timeout=30,
    )
    r.raise_for_status()
    session.headers.update({"Authorization": f"Bearer {r.json()['access_token']}"})

    # CSRF Token
    csrf = session.get(f"{BASE}/api/v1/security/csrf_token", timeout=30).json().get("result")
    session.headers.update({"X-CSRFToken": csrf})

    # Fetch dataset
    data = session.get(
        f"{BASE}/api/v1/dataset/{dataset_id}/data",
        params={"format": "json", "row_limit": row_limit},
        timeout=60,
    ).json()

    return pd.DataFrame(data)


if __name__ == "__main__":
    df = fetch_superset_dataset(dataset_id=1)  # change dataset ID
    print(df.head())
