import requests
import pandas as pd

BASE = "http://localhost:8088"   # Superset URL
USER = "admin"
PWD = "admin"
DATASET_ID = 1                   # <-- update with your dataset ID
REFERENCE_CSV = "project_timeline_big.csv"

# Step 1: login
s = requests.Session()
r = s.post(
    f"{BASE}/api/v1/security/login",
    json={"provider": "db", "username": USER, "password": PWD, "refresh": True},
)
r.raise_for_status()
token = r.json()["access_token"]
s.headers.update({"Authorization": f"Bearer {token}"})

# Step 2: fetch data from Superset dataset
data = s.get(
    f"{BASE}/api/v1/dataset/{DATASET_ID}/data",
    params={"format": "json", "row_limit": 1000},
).json()

print(data)   # debug: show raw Superset API response

# Extract rows from Superset
df_superset = pd.DataFrame(data["result"])

# Step 3: load reference
df_ref = pd.read_csv(REFERENCE_CSV)

# Step 4: compare on task/owner
JOIN_KEYS = ["task"]
VALUE_COL = "owner"

merged = df_superset.merge(df_ref, on=JOIN_KEYS, how="outer", suffixes=("_superset","_ref"))
merged["status"] = merged.apply(
    lambda r: "match" if r.get(f"{VALUE_COL}_superset") == r.get(f"{VALUE_COL}_ref") else "mismatch",
    axis=1,
)

# Step 5: export report
merged.to_csv("project_timeline_report.csv", index=False)
print(merged["status"].value_counts())

