from flask import Flask, request, jsonify
import openai
import os
from query_agent import summarize_data

app = Flask(__name__)

# Use env var instead of hardcoding the key
openai.api_key = "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"

@app.route("/", methods=["GET"])
def home():
    return "✅ AI Superset Assistant is running! Use POST /summarize to summarize data."

@app.route("/summarize", methods=["POST"])
def summarize():
    try:
        data = request.json.get("data")
        if not data:
            return jsonify({"error": "No data provided"}), 400

        # Call your local summarizer first
        summary = summarize_data(data)

        # Then refine with OpenAI
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a helpful AI assistant summarizing project data."},
                {"role": "user", "content": f"Summarize this data: {summary}"}
            ],
            temperature=0.3,
        )

        ai_summary = response["choices"][0]["message"]["content"]

        return jsonify({
            "local_summary": summary,
            "ai_summary": ai_summary
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
