import openai
from db import run_query

openai.api_key = "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"  # <-- put in env later


def summarize_data(data):
    prompt = f"Here is dashboard data: {data}\nGenerate a short insight summary."
    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message["content"]

