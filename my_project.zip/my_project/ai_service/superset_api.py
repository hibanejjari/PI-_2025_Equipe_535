import requests

BASE_URL = "http://localhost:8088"

def get_token(username="admin", password="admin"):
    url = f"{BASE_URL}/api/v1/security/login"
    payload = {
        "username": username,
        "password": password,
        "provider": "db",
        "refresh": True
    }
    resp = requests.post(url, json=payload)
    resp.raise_for_status()
    return resp.json()["access_token"]

if __name__ == "__main__":
    token = get_token("admin", "admin")  # replace with your Superset credentials
    print("✅ Token:", token)
