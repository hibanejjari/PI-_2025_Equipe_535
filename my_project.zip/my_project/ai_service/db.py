import os
from dotenv import load_dotenv
import psycopg2

# Load .env (force UTF-8)
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), "../docker/.env"))

def get_connection():
    conn = psycopg2.connect(
        dbname=os.getenv("POSTGRES_DB", "superset"),
        user=os.getenv("POSTGRES_USER", "superset"),
        password=os.getenv("POSTGRES_PASSWORD", "superset"),
        host=os.getenv("DATABASE_HOST", "localhost"),  # "db" inside docker, "localhost" outside
        port=os.getenv("DATABASE_PORT", "5432"),
        options='-c client_encoding=UTF8'
    )
    return conn

def run_query(query):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(query)
    result = cur.fetchall()
    conn.close()
    return result

if __name__ == "__main__":
    try:
        rows = run_query("SELECT table_name FROM information_schema.tables WHERE table_schema='public' LIMIT 5;")
        print("✅ Connected! Found tables:", rows)
    except Exception as e:
        print("❌ Connection failed:", e)


